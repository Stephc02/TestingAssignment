package weatherapp.recommendations;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class WeatherTest {

    @Test
    public void testClothingRecommendation_ColdTemperature_Raining() {
        String weatherData = "{\"current\": {\"temp_c\": 10, \"precip_mm\": 5}}";

        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);

        String recommendation = app.recommendClothing(weatherData);

        assertEquals("It is cold so you should wear warm clothing.\nIt is currently raining so you do need an umbrella.", recommendation);
    }

    @Test
    public void testClothingRecommendation_ColdTemperature_NotRaining() {
        String weatherData = "{\"current\": {\"temp_c\": 10, \"precip_mm\": 0}}";

        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);

        String recommendation = app.recommendClothing(weatherData);

        assertEquals("It is cold so you should wear warm clothing.\nIt is not raining so you don't need an umbrella.", recommendation);
    }

    @Test
    public void testClothingRecommendation_WarmTemperature_Raining() {
        String weatherData = "{\"current\": {\"temp_c\": 20, \"precip_mm\": 5}}";

        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);

        String recommendation = app.recommendClothing(weatherData);

        assertEquals("It is warm so you should wear light clothing.\nIt is currently raining so you do need an umbrella.", recommendation);
    }

    @Test
    public void testClothingRecommendation_WarmTemperature_NotRaining() {
        String weatherData = "{\"current\": {\"temp_c\": 20, \"precip_mm\": 0}}";

        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);

        String recommendation = app.recommendClothing(weatherData);

        assertEquals("It is warm so you should wear light clothing.\nIt is not raining so you don't need an umbrella.", recommendation);
    }
}

