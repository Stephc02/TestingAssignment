package weatherapp.recommendations;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class FailoverserviceTest {

    @Test
    public void testLocationRetriever_TimeoutSwitchToSecondaryService() {
        WeatherApp33.LocationRetriever locationRetriever = new WeatherApp33.LocationRetriever();
        WeatherApp33.LocationRetriever locationRetrieverSpy = spy(locationRetriever);

        // Mocking the primary location request to simulate timeout (no reply within 3 seconds)
        doAnswer(invocation -> {
            Thread.sleep(4000); // Simulating a delay longer than the timeout (3 seconds)
            return null; // Returning null as there's no reply within the timeout
        }).when(locationRetrieverSpy).fetchUserLocation(anyString());

        // Mock the secondary service behavior
        doReturn("Secondary Location").when(locationRetrieverSpy).fetchUserLocationBackup(anyString());

        // Call the method that handles the location retrieval
        String userLocation = locationRetrieverSpy.getUserLocation();

        // Assert that the secondary service is used after the timeout
        assertEquals("Secondary Location", userLocation);
    }
}
