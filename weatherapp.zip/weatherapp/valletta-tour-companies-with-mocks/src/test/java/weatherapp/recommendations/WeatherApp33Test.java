package weatherapp.recommendations;

// Import the necessary libraries
import static junit.framework.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

// Create a test class for WeatherApp33
public class WeatherApp33Test {

    // Create a mock of InputReader
    @Mock
    private InputReader mockInputReader;

    // Create a spy of WeatherApp33
    private WeatherApp33 weatherApp;

    // Initialize the mocks and the spy before each test
    @BeforeEach
    public void setUp () {
        MockitoAnnotations.initMocks (this);
        weatherApp = Mockito.spy (new WeatherApp33 (mockInputReader));
    }

    // Test that recommendCurrentWeather is called when user inputs option 1
    // THIS WORKS
    @Test
    public void testRecommendCurrentWeatherCalledWhenOptionIsOne () {
        // Stub the inputReader to return 1 when nextInt is called
        when (mockInputReader.nextInt ()).thenReturn (1);

        // Call the run method of weatherApp
        weatherApp.run ();

        // Verify that recommendCurrentWeather was called once with any string as the apiKey
        verify (weatherApp, times (1)).recommendCurrentWeather (anyString ());
    }


    @Test
    public void testRecommendFutureWeatherCalledWhenOptionIsTwo () {
        // Stub the inputReader to return 1 when nextInt is called
        when (mockInputReader.nextInt ()).thenReturn (2);
        when (mockInputReader.nextLine ()).thenReturn ("EGLL", "2023-11-25");

        // Call the run method of weatherApp
        weatherApp.run ();

        // Verify that recommendCurrentWeather was called once with any string as the apiKey
        verify (weatherApp, times (1)).recommendFutureWeather (anyString (), anyString (), anyString ());
    }





    /*
    // Test that recommendFutureWeather is called when user inputs option 2 and valid inputs
    @Test
    public void testRecommendFutureWeatherCalledWhenOptionIsTwoAndValidInputs () {
        // Stub the inputReader to return 2, "EGLL", and "2023-11-25" when nextInt and nextLine are called
        when (mockInputReader.nextInt ()).thenReturn (2);
        when (mockInputReader.nextLine ()).thenReturn ("EGLL", "2023-11-25");

        // Call the run method of weatherApp
        weatherApp.run ();

        // Verify that recommendFutureWeather was called once with the given apiKey, airportICAOCode, and dateOfArrival
        verify (weatherApp, times (1)).recommendFutureWeather ("aeb8d88d29mshef7dc5a22fb52dap1e0493jsnb0b2c439ae31", "EGLL", "2023-11-25");
    } */

    // Test that an error message is displayed when user inputs option 4 which doesn't exist
    @Test
    public void testErrorMessageDisplayedWhenOptionIsFourWhichDoesntExist () {
        // Stub the inputReader to return 4 when nextInt is called
        when (mockInputReader.nextInt ()).thenReturn (4);

        // Call the run method of weatherApp
        weatherApp.run ();

        // Verify that an error message was printed to the standard output
        verify (System.out, times (1)).println ("Invalid choice. Please try again.");
    }




    @Test
    // Add your test annotations here (e.g., @Test)
    void testInvalidOptionErrorMessage() {
        InputReader mockInputReader = mock(InputReader.class);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Simulate user input of option 4 (an invalid option)
        when(mockInputReader.nextInt()).thenReturn(4);

        // Create the WeatherApp instance with the mocked input reader
        WeatherApp33 weatherApp = new WeatherApp33(mockInputReader);

        // Run the WeatherApp
        weatherApp.run();

        // Get the output from the outputStream
        String fullOutput = outputStream.toString();
        String[] lines = fullOutput.split("\n");

       // Get the last line which contains the error message
        String actualErrorMessage = lines[lines.length - 1];

        // Verify that the error message is displayed
        String expectedErrorMessage = "Enter choice: Invalid choice. Please try again.";
        assertEquals(expectedErrorMessage, actualErrorMessage.trim());
    }






}
