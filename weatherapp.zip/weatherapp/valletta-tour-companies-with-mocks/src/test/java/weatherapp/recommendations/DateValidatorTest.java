package weatherapp.recommendations;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DateValidatorTest {

    @Test
    public void testValidDates() {


        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);

        // Test valid dates
        assertTrue(app.isValidDate("2023-11-25")); // Within 10 days
        assertTrue(app.isValidDate("2023-11-29")); // Exactly 10 days
        assertFalse(app.isValidDate("2023-11-10")); // Past date
        assertFalse(app.isValidDate("2024-01-01")); // Future date
    }

    @Test
    public void testInvalidDates() {

        InputReader inputReader = new InputReader() {
            @Override
            public int nextInt() {
                return 0;
            }

            @Override
            public String nextLine() {
                return null;
            }
        };
        WeatherApp33 app = new WeatherApp33(inputReader);




        // Test invalid dates
        assertFalse(app.isValidDate("2023-11-31")); // Invalid day
        assertFalse(app.isValidDate("Hello World")); // Non-date string
        assertFalse(app.isValidDate("")); // Empty string
        assertFalse(app.isValidDate(null)); // Null input
    }


}
