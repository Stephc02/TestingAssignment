package weatherapp.recommendations;

public interface InputReader {
    int nextInt();

    String nextLine();
}
