package weatherapp.recommendations;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


public class WeatherApp33 {

    private WeatherApp33 weatherApp;

    public static void main(String[] args) {
        // Create an instance of ScannerInputReader
        Scanner scanner = new Scanner(System.in);
        InputReader inputReader = new ScannerInputReader(scanner);


        // Pass the inputReader instance to the WeatherApp33 constructor
        WeatherApp33 app = new WeatherApp33(inputReader);


        app.run();
    }

    private final InputReader inputReader;
    private int loopCounter = 0;

    public WeatherApp33(InputReader inputReader) {
        this.inputReader = inputReader;
    }




   void run() {
        Scanner scanner = new Scanner(System.in);
        String apiKey = "aeb8d88d29mshef7dc5a22fb52dap1e0493jsnb0b2c439ae31";

        while (loopCounter < 1) {
            displayMainMenu();

            /*
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline */

            int choice = inputReader.nextInt();
            inputReader.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                  recommendCurrentWeather(apiKey);
                    break;
                case 2:
                    // Add feature 2: Recommend clothing for future location
                    System.out.print("Enter Airport ICAO Code (e.g., EGLL): ");
                    String airportICAOCode = scanner.nextLine();

                    System.out.print("Enter Date of Arrival (YYYY-MM-DD): ");
                    String dateOfArrival = scanner.nextLine();

                    // Validate the date (it should not be more than 10 days in the future)
                    if (isValidDate(dateOfArrival)) {
                      recommendFutureWeather(apiKey, airportICAOCode, dateOfArrival);
                    } else {
                        System.out.println("Invalid date. Please enter a valid date within the next 10 days.");
                    }

                    break;
                case 3:
                    System.out.println("Exiting WeatherWear.com");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            loopCounter++;
        }
    }   // end of run method


    public void displayMainMenu() {
        System.out.println("WeatherWear.com");
        System.out.println("---------------");
        System.out.println("1. Recommend clothing for current location");
        System.out.println("2. Recommend clothing for future location");
        System.out.println("3. Exit");
        System.out.print("Enter choice: ");
    }



    public boolean isValidDate(String date) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false); // Ensure strict date parsing

            Date parsedDate = dateFormat.parse(date);
            Date currentDate = new Date();

            long timeDifference = parsedDate.getTime() - currentDate.getTime();
            long tenDaysInMilliseconds = 10L * 24 * 60 * 60 * 1000;

            return timeDifference >= 0 && timeDifference <= tenDaysInMilliseconds;
        } catch (ParseException | NullPointerException e) {
            // Log or handle the exception as needed
            e.printStackTrace();
            return false;
        }
    }




    public static class LocationRetriever {
        public static final String apiKey = "aeb8d88d29mshef7dc5a22fb52dap1e0493jsnb0b2c439ae31";
        public String userIpAddress; // Declare it at the class level

        public LocationRetriever() {

            userIpAddress = getUserIPAddress();
        }


        // This method gets the user's location from the Weather IP lookup API using their IP address.
        public String getUserLocation() {
            userIpAddress = getUserIPAddress();

            // Create an ExecutorService
            ExecutorService executorService = Executors.newFixedThreadPool(1);

            // Create a Future for the primary location request
            Future<String> primaryLocationFuture = executorService.submit(() -> fetchUserLocation(userIpAddress));

            try {
                // Wait for the result with a timeout of 3 seconds
                String location = primaryLocationFuture.get(3, TimeUnit.SECONDS);

                // Shutdown the executor service
                executorService.shutdown();

                if (location != null) {
                    return location;
                }
            } catch (Exception e) {
                // Handle exceptions, including TimeoutException
                e.printStackTrace();

                // If the primary location request times out, fall back to the backup service
                System.out.println("Primary location service timed out. Falling back to the backup service.");
                return fetchUserLocationBackup(userIpAddress);
            } finally {
                // Ensure the executor service is shut down
                executorService.shutdown();
            }

            return null; // Unable to determine the user's IP address or location.


        }



        public String getUserIPAddress() {
            try {
                URL url = new URL("https://httpbin.org/ip");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                connection.disconnect();

                return parsePublicIPAddress(response.toString());
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public String parsePublicIPAddress(String response) {
            try {
                JSONObject jsonResponse = new JSONObject(response);
                return jsonResponse.getString("origin");
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }


        // USING THE PRIMARY IP SERVICE
        public String fetchUserLocation(String userIpAddress) {
            String geolocationServiceUrl = "https://weatherapi-com.p.rapidapi.com/ip.json?q=" + userIpAddress;

            try {
                URL url = new URL(geolocationServiceUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-RapidAPI-Key", apiKey);
                //Thread.sleep(4000);

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                String userLocation = parseUserLocationFromResponse(response.toString());
                connection.disconnect();

                return userLocation;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }

        }



        public String fetchUserLocationBackup(String userIpAddress) {
            String geolocationServiceUrl = "http://ip-api.com/json/" + userIpAddress;

            try {
                URL url = new URL(geolocationServiceUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");


                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                String userLocation = parseUserLocationFromResponseBackup(response.toString());
                connection.disconnect();

                return userLocation;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }




        public String parseUserLocationFromResponse(String response) {
            try {
                JSONObject jsonResponse = new JSONObject(response);

                // Check if the "country_name" key is present in the JSON response
                if (jsonResponse.has("country_name")) {
                    String countryName = jsonResponse.getString("country_name");
                    System.out.println(response);
                    return countryName;

                } else {
                    // Handle the case where the "country_name" key is not found in the response
                    System.err.println("country_name key not found in the JSON response.");
                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }


        public String parseUserLocationFromResponseBackup(String response) {
            try {
                JSONObject jsonResponse = new JSONObject(response);

                // Check if the "country_name" key is present in the JSON response
                if (jsonResponse.has("country")) {
                    String country = jsonResponse.getString("country");
                    System.out.println(response);
                    return country;

                } else {
                    // Handle the case where the "country_name" key is not found in the response
                    System.err.println("country key not found in the JSON response.");
                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }



    }



       public LocationRetriever locationRetriever = new LocationRetriever();


        //FEATURE 1
        public void recommendCurrentWeather(String apiKey) {




            String userLocation = locationRetriever.getUserLocation(); // Get the user's location, not IP address
            String weatherAPIUrl = "https://weatherapi-com.p.rapidapi.com/current.json?q=35.89563880%2C14.48688830";

            String geolocationServiceUrl = "https://weatherapi-com.p.rapidapi.com/ip.json?q=193.188.47.71";

            // Create an HttpClient instance with your API key in the headers
            HttpClient httpClient = HttpClient.newBuilder()
                    .version(HttpClient.Version.HTTP_2)
                    .build();


            if (userLocation != null) {


                System.out.println("User Location: " + userLocation); // Print user's location. ADDED JUST NOW

                // Step 2: Get current weather data for the user's location using the Weather API
                String weatherData = getWeatherData(httpClient, weatherAPIUrl, apiKey, userLocation);



                if (weatherData != null) {

                    // Print the weather data to check what you're receiving
                    System.out.println("Weather Data: " + weatherData); //just added


                    // Step 3: Apply clothing recommendation algorithm based on weather data
                    String recommendation = recommendClothing(weatherData);

                    // Step 4: Display the recommendation to the user
                    System.out.println("Clothing Recommendation: " + recommendation);
                } else {
                    System.out.println("Failed to fetch weather data.");
                }
            } else {
                System.out.println("Failed to fetch user location.");
            }
        }


        public String getWeatherData(HttpClient httpClient, String weatherAPIUrl, String apiKey, String location) {
            try {
                // Create the URL for the weather service
                URL url = new URL(weatherAPIUrl);

                // Create an HttpRequest with headers, including the API key
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(url.toURI())
                        .header("X-RapidAPI-Key", apiKey)
                        .header("Content-Type", "application/json")
                        .build();

                // Send the request and get the response
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                // Check if the request was successful (HTTP status code 200)
                if (response.statusCode() == 200) {
                    return response.body();
                } else {
                    System.out.println("Weather API request failed with status code: " + response.statusCode());
                    return null;
                }
            } catch (Exception e) {
                // Handle any errors, log, and return null in case of an issue
                e.printStackTrace();
                return null;
            }
        }


        public String recommendClothing(String weatherData) {
            try {
                // Parse the weather data from the JSON string
                JSONObject jsonResponse = new JSONObject(weatherData);
                JSONObject currentWeather = jsonResponse.getJSONObject("current");

                // Extract relevant weather information
                double temperature = currentWeather.getDouble("temp_c");
                double precipitation = currentWeather.getDouble("precip_mm"); // Access it as a double

                // Determine clothing and umbrella recommendations
                String temperatureCategory = temperature <= 15 ? "cold" : "warm";
                String clothingRecommendation = temperatureCategory.equals("cold") ? "warm" : "light";

                String rainRecommendation = precipitation > 0 ? "do" : "don't";

                // Generate the clothing and umbrella recommendations
                String clothingMessage = String.format("It is %s so you should wear %s clothing.", temperatureCategory, clothingRecommendation);
                String umbrellaMessage = String.format("It is %s raining so you %s need an umbrella.", (precipitation > 0) ? "currently" : "not", rainRecommendation);

                // Combine the recommendations into a single message
                return clothingMessage + "\n" + umbrellaMessage;
            } catch (Exception e) {
                // Handle any errors, log, and return a default recommendation in case of an issue
                e.printStackTrace();
                return "Unable to provide clothing recommendations at this time.";
            }
        }



        public void recommendFutureWeather(String apiKey, String airportICAOCode, String dateOfArrival) {
            String weatherAPIUrl = "https://weatherapi-com.p.rapidapi.com/forecast.json?q=London&days=10" + airportICAOCode + "&dt=" + dateOfArrival;
            // Implementation for future weather recommendation based on airport ICAO code and date
            // Create an HttpClient instance with your API key in the headers
            HttpClient httpClient = HttpClient.newBuilder()
                    .version(HttpClient.Version.HTTP_2)
                    .build();

            // Step 2: Get weather data for the destination airport and date of arrival
            String weatherData = getWeatherData(httpClient, weatherAPIUrl, apiKey, null);

            if (weatherData != null) {
                // Step 3: Apply clothing recommendation algorithm based on weather data
                String recommendation = recommendClothing(weatherData);

                // Step 4: Display the recommendation to the user
                System.out.println("Clothing Recommendation for " + airportICAOCode + " on " + dateOfArrival + ": " + recommendation);
            } else {
                System.out.println("Failed to fetch weather data for the future location.");
            }
        }



    }





